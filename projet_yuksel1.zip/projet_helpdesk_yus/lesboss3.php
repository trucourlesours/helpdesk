<?php
require_once('require.php');

if ($_SESSION['role'] !== 'admin') {
    header('Location: la_base.php');
    exit;
}

if (isset($_POST['btn_role'])) {
    $user_id  = $_POST['user_id'];
    $new_role = $_POST['new_role'];

    $query = "UPDATE users SET role = ? WHERE id = ?";
    $stmt  = mysqli_prepare($db, $query);
    mysqli_stmt_bind_param($stmt, "si", $new_role, $user_id);
    mysqli_stmt_execute($stmt);

    header('Location: lesboss3.php');
    exit;
}

$query  = "SELECT * FROM users";
$stmt   = mysqli_prepare($db, $query);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Changer les rôles</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <a href="lesboss.php"><button type="button">Retour</button></a>

    <h1 >Gestion des rôles</h1>

    <table>
        <thead>
            <tr>
                <th>Nom</th>
                <th>Rôle actuel</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($result)){ ?>
                <tr>
                    <td><?= $row['nom'] ?></td>
                    <td><?= $row['role'] ?></td>
                    <td>
                        <form action="" method="POST">
                            <input type="hidden" name="user_id" value="<?= $row['id'] ?>">
                            <select name="new_role">
                                <option value="user">User</option>
                                <option value="technicien">Technicien</option>
                                <option value="admin">Admin</option>
                            </select>
                            <button type="submit" name="btn_role">Changer</button>
                        </form>
                    </td>
                </tr>
            <?php }; ?>
        </tbody>
    </table>
</body>
</html>