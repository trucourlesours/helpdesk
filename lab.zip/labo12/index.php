<?php
session_start();

$msg_tentative = "";
$msg_rep = "";
$jeu_termine = false;

var_dump($_SESSION["a_trouver"]);


// Demarrage d'une nouvelle partie
if(!isset($_SESSION['a_trouver'])) {
    $_SESSION['a_trouver'] = rand(0, 100);
    $_SESSION['tentatives'] = 5;
    $msg_tentative = "Vous avez 5 tentatives pour trouver le nombre entre 0 et 100.";
}

if(isset($_POST['relancer'])) {
    $_SESSION['a_trouver'] = rand(0, 100);
    $_SESSION['tentatives'] = 5;
    $msg_tentative = "Vous avez relancer une partie , vous avez  5 tentatives pour trouver le nombre entre 0 et 100.";
    
}

if (isset($_SESSION['a_trouver']) && isset($_POST['envoyer'])) {
    $_SESSION['tentatives']--;

    if ($_POST['chiffre'] > $_SESSION['a_trouver']) {
        $msg_rep = "Le nombre a trouver est plus petit.";
        $msg_tentative = "Il vous reste " . $_SESSION['tentatives'] . " tentative(s).";
    } 
    elseif ($_POST['chiffre'] < $_SESSION['a_trouver']) {
        $msg_rep = "Le nombre a trouver est plus grand.";
        $msg_tentative = "Il vous reste " . $_SESSION['tentatives'] . " tentative(s).";
    } 
    else {
        $msg_tentative = "Bravo ! Vous avez trouve le nombre !";
        $msg_rep = "";
        $jeu_termine = true;
        session_unset();
        session_destroy();
    }

    if (!$jeu_termine && $_SESSION['tentatives'] <= 0) {
        $msg_tentative = "Vous avez perdu ! Le nombre a trouver etait " . $_SESSION['a_trouver'] . ".";
        $msg_rep = "";
        $jeu_termine = true;
        session_unset();
        session_destroy();
    }
}


?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jeu des 5 tentatives</title>
    <style>
        #zone_jeu {
            width: 400px;
            min-height: 300px;
            border: 5px solid black;
            margin: auto;
            text-align: center;
            padding: 15px;
        }
        
    </style>
</head>
<body>
    <h2>Lapinski</h2>
    <div id="zone_jeu">
        <h4>Jeu des 5 tentatives</h4>

        <form action="" method="post">
            <input type="number" name="chiffre" min="0" max="100" required>
            <button type="submit" name="envoyer">Envoyer</button>
        </form>
        
        <br><br>
        <h5><?= $msg_tentative ?></h5>
        <h5><?= $msg_rep ?></h5>

        <?php if($jeu_termine): ?>
        <br>
        <form action="" method="post">
            <button type="submit" name="relancer" >Relancer le jeu</button>
        </form>
        <?php endif; ?>
    </div>
</body>
</html>