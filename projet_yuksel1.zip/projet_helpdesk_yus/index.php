<?php
require_once('require.php');

$error = "";

if (isset($_POST['btn_login'])) {
    $nom  = $_POST['username'];
    $email  = $_POST['email'];
    $password = $_POST['password'];

    $query = "SELECT * FROM users WHERE email = ?";
    $stmt  = mysqli_prepare($db, $query);
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $user   = mysqli_fetch_assoc($result);

    if ($user && password_verify($password, $user['mot_de_passe'])) {
        $_SESSION['user_id']  = $user['id'];
        $_SESSION['username'] = $user['nom'];
        $_SESSION['role']     = $user['role'];
        header('Location: la_base.php');
        exit;
    } else {
        $error = "Email ou mot de passe incorrect.";
    }
};
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1 >Connexion</h1>

    <?php if ($error){ ?>
        <p class="msg-error"><?= $error ?></p>
    <?php }; ?>

    <form action="" method="POST">
        <label>Nom</label>
        <input type="text" name="username" placeholder="Votre Nom" required>

        <label>Email</label>
        <input type="email" name="email" placeholder="Votre Mail" required>

        <label>Mot de passe</label>
        <input type="password" name="password" placeholder="Votre Mot de passe" required>

        <button type="submit" name="btn_login">Se connecter</button>
    </form>

    <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'){ ?>
    <a href="inscription.php">
        <button type="button" style="margin-top: 20px;">
            Pas encore de compte ?
        </button>
    </a>
<?php }; ?>
</body>
</html>