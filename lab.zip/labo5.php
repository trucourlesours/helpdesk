<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>labo5php</title>
<style>
fieldset {
            width: 50%;           
            margin: 20px auto;    
            padding: 10px;        
            border: 2px solid #000; 
        }
table{
    border:3px solid black;
    width: 100%; 

}
td{
    border:1px solid black;

}


</style>
</head>
<body>

        <h2>Yuksel php labo 5</h2>
<?php
    $tab = array(
            2 => "phrases",
            7 => "ordre",
            4 => "dans",
            3 => "est",
            1 => "cette",
            6 => "bon",
            5 => "le",
    );
?>

<fieldset>
    <legend>Exercice boucle FOR sur vriable tableau</legend>
    <?php
    for($i=1;$i<8;$i++){
        print("$tab[$i] ");

    }
    ?>
    
</fieldset>
<fieldset>
    <legend>Exercice boucle FOREACH sur la variable tableau</legend>
    <table>
        <tr><td>Nom de l'etudiant</td><td>Point</td></tr>
        <?php
        $etudiants =array('tom'=>rand(0,100),'Salima'=>rand(0,100),'Eric'=>rand(0,100),'Lea'=>rand(0,100),'Marco'=>rand(0,100),);
            foreach ($etudiants as $key => $value) {
                print("<tr><td>".$key."</td><td>".$value."<td></tr>");
            }

        ?>

    </table>


    <?php
        $somme = array_sum($etudiants);
        $nombre = count($etudiants);
        $moyenne = $somme / $nombre;
        print("<tr><td colspan='2' style='text-align:center;'>La moyenne des élèves est : $moyenne </td></tr>");
        
        
    ?>
    <?php
    $max=0;
    $meilleur ='';
    $echec =0;
    foreach ($etudiants as $key => $value) {
        if($value > $max){
            $max = $value;
            $meilleur = $key;
        }
        if($value < 50){
            $echec++;


        }
        else{

        }
    }

    print("<br>La meilleur cote appartient a " .$meilleur ." qui a eu " .$value);
    print("<br>Il y a " .$echec ." echecs");


    ?>

</fieldset>



</body>
</html>