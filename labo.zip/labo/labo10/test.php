<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Labo 10 (BD + bootstrap)</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
    <style>
        .table{
            width:1100px;
            margin:auto auto;
        }
        td{
            /*border:1px solid black;*/
        }
        #form_filtre{
            margin:25px;
        }
    </style>
</head>
<body>
    <h3>Y</h3>

    <form action="" method="post" id="form_filtre">
        <input type="text" name="titre">
        <input type="submit" value="Rechercher un film" name="filtre_film">
    </form>

    <form action="" method="post">
        <select name="statut">
            <option value="AFFICHE">Films à l'affiche</option>
            <option value="ARCHIVE">Films archivés</option>
        </select>
        <input type="submit" value="Filtrer les films" name='statut_film'>
    </form>
    <?php
        $serveur = 'localhost';
        $bdname = 'irigaray';
        $login = 'root';
        $mdp = '';
        

        $link=mysqli_connect($serveur,$login,$mdp,$bdname);
        
        if (!$link) {
            die("La connexion a échoué: " . mysqli_connect_error());
        }

        if(isset($_POST['effacer'])){
            foreach ($_POST['del'] as $value) {
                mysqli_query($link,"delete from films where id=".$value);
            }
        }





        $res = mysqli_query($link,"select * from films order by titre ASC");

        if(isset($_POST['filtre_film']) && !empty($_POST['titre'])){
            $res = mysqli_query($link,"select * from films where titre LIKE '%".$_POST['titre']."%' order by titre ASC");
        }

        if(isset($_POST['statut_film'])){
            $res = mysqli_query($link,"select * from films where statut = '".$_POST['statut']."' order by titre ASC");
        }

        if(mysqli_num_rows($res) > 0){
            print("
            <form action='' method='post'>
                <table class='table table-striped'>
                        <tr>
                            <th>Titre</th>
                            <th>Origine</th>
                            <th>Date de sortie</th>
                            <th>Effacer</th>
                            
                        </tr>
                        ");

            while($ligne=mysqli_fetch_assoc($res)){
                print("<tr>
                            <td>".$ligne['titre']."</td>
                            <td>".$ligne['origine']."</td>
                            <td>".$ligne['dateSortie']."</td>
                            <td><input type='checkbox' name='del[]' value='".$ligne['id']."'></td>
                            
                      </tr>");
            }

            print("
            <tr>
                <td></td>
                <td></td>
                <td></td>
                <td><input type='submit' value='Effacer' name='effacer'></td>
            </tr>
            </table>
            </form>");
        }
        ?>
</body>
</html>
