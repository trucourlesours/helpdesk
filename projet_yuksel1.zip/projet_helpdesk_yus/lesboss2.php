<?php
require_once('require.php');

$ticket_id = $_GET['id'];

if (isset($_POST['btn_send'])) {
    $message = $_POST['msg_input'];

    $query = "INSERT INTO messages (id_ticket, id_utilisateur, message, cree_le) VALUES (?, ?, ?, NOW())";
    $stmt  = mysqli_prepare($db, $query);
    mysqli_stmt_bind_param($stmt, "iis", $ticket_id, $_SESSION['user_id'], $message);
    mysqli_stmt_execute($stmt);

    header('Location: lesboss2.php?id=' . $ticket_id);
    exit;
}

$q_ticket = "SELECT tickets.*, users.nom FROM tickets JOIN users ON tickets.id_utilisateur = users.id WHERE tickets.id = ?";
$s_ticket = mysqli_prepare($db, $q_ticket);
mysqli_stmt_bind_param($s_ticket, "i", $ticket_id);
mysqli_stmt_execute($s_ticket);
$ticket = mysqli_fetch_assoc(mysqli_stmt_get_result($s_ticket));

$q_msg = "SELECT messages.*, users.nom FROM messages
          JOIN users ON messages.id_utilisateur = users.id
          WHERE id_ticket = ?";
$s_msg = mysqli_prepare($db, $q_msg);
mysqli_stmt_bind_param($s_msg, "i", $ticket_id);
mysqli_stmt_execute($s_msg);
$messages = mysqli_stmt_get_result($s_msg);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Ticket #<?= $ticket_id ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="card">
        <a href="lesboss.php"><button type="button">Retour</button></a>

        <h1 >Sujet : <?= htmlspecialchars($ticket['sujet']) ?></h1>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Utilisateur</th>
                    <th>Message</th>
                    <th>Temps</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?= $ticket['id'] ?></td>
                    <td><?= htmlspecialchars($ticket['nom']) ?></td>
                    <td><?= htmlspecialchars($ticket['message']) ?></td>
                    <td><?= date('H:i', strtotime($ticket['cree_le'])) ?></td>
                </tr>
            </tbody>
        </table>

        <hr>

        <?php while ($row = mysqli_fetch_assoc($messages)){ ?>
            <p><strong><?= htmlspecialchars($row['nom']) ?></strong> : <?= htmlspecialchars($row['message']) ?> <small>(<?= date('H:i', strtotime($row['cree_le'])) ?>)</small></p>
        <?php }; ?>

        <hr>

        <form action="" method="POST">
            <label>Votre réponse</label>
            <textarea name="msg_input" placeholder="Écrivez votre réponse..." required></textarea>
            <button type="submit" name="btn_send">Envoyer</button>
        </form>
    </div>
</body>
</html>