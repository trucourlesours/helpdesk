<?php
require_once("require.php");

if ($_SESSION['role'] !== 'technicien' && $_SESSION['role'] !== 'admin') {
    header('Location: la_base.php');
    exit;
}

if (isset($_POST['btn_statut'])) {
    $ticket_id = $_POST['ticket_id'];
    $statut    = $_POST['new_statut'];

    $query = "UPDATE tickets SET statut = ? WHERE id = ?";
    $stmt  = mysqli_prepare($db, $query);
    mysqli_stmt_bind_param($stmt, "si", $statut, $ticket_id);
    mysqli_stmt_execute($stmt);

    header('Location: lesboss.php');
    exit;
}

$query  = "SELECT tickets.*, users.nom FROM tickets JOIN users ON tickets.id_utilisateur = users.id";
$stmt   = mysqli_prepare($db, $query);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des tickets</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <a href="la_base.php"><button type="button">Retour</button></a>

    <h1 >Gestion des tickets</h1>

    <table>
        <thead>
            <tr>
                <th>Sujet</th>
                <th>Message</th>
                <th>Temps</th>
                <th>Utilisateur</th>
                <th>Statut</th>
                <th>Ouvrir</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($result)){ ?>
                <tr>
                    <td><?= $row['sujet'] ?></td>
                    <td><?= $row['message'] ?></td>
                    <td><?= date('H:i', strtotime($row['cree_le'])) ?></td>
                    <td><?= $row['nom'] ?></td>
                    <td><?= $row['statut'] ?></td>
                    <td><a href="lesboss2.php?id=<?= $row['id'] ?>">Voir</a></td>
                    <td>
                        <form action="" method="POST">
                            <input type="hidden" name="ticket_id" value="<?= $row['id'] ?>">
                            <select name="new_statut">
                                <option value="ouvert">Ouvert</option>
                                <option value="en_cours">En cours</option>
                                <option value="fermer">Fermé</option>
                            </select>
                            <button type="submit" name="btn_statut">Changer</button>
                        </form>
                    </td>
                </tr>
            <?php }; ?>
        </tbody>
    </table>

    <?php if ($_SESSION['role'] === 'admin'){ ?>
        <div style="margin-top: 20px;">
            <a href="lesboss3.php"><button type="button">Changer les rôles</button></a>
        </div>
    <?php }; ?>
</body>
</html>