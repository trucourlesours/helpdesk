<?php
var_dump($_POST);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">

    <style>
        table{
            background-color: <?= isset($_POST['couleur']) ? $_POST['couleur'] : "#fff"; ?>;
        }
    </style>
</head>
<body>
    <h2>Terresti Ali</h2>

    <form action="" method="post">
        <table>
            <tr>
                <td>Entrez votre nom :</td>
                <td><input type="text" name="le_nom" required></td>
            </tr>

            <tr>
                <td>Entrez votre prénom :</td>
                <td><input type="text" name="le_prenom"></td>
            </tr>

            <tr>
                <td>Entrez votre mot de passe :</td>
                <td><input type="password" name="le_mdp"></td>
            </tr>

            <tr>
                <td>Entrez votre date de naissance :</td>
                <td><input type="date" name="naissance"></td>
            </tr>

            <tr>
                <td>Entrez votre email :</td>
                <td><input type="email" name="mail" required></td>
            </tr>

            <tr>
                <td>Niveau d'étude :</td>
                <td>
                    <select name="etudes">
                        <option value="pri">Niveau Primaire</option>
                        <option value="sec">Niveau Secondaire</option>
                        <option value="uni">Niveau Universitaire</option>
                    </select>
                </td>
            </tr>

            <tr>
                <td>Entrez votre sexe :</td>
                <td>
                    <input type="radio" name="sexe" value="f"> Femme<br>
                    <input type="radio" name="sexe" value="m"> Homme
                </td>
            </tr>

            <tr>
                <td>Entrez votre couleur préférée :</td>
                <td><input type="color" name="couleur"></td>
            </tr>

            <tr>
                <td>Entrez vos activités :</td>
                <td>
                    <input type="checkbox" name="hobby[]" value="Sport"> Sport<br>
                    <input type="checkbox" name="hobby[]" value="Musique"> Musique<br>
                    <input type="checkbox" name="hobby[]" value="Jeux vidéo"> Jeux vidéo
                </td>
            </tr>
              <td>Entrez votre texte :</td>
              <td>
                <textarea name="msg"  cols="30" rows="6"></textarea>
    </td>

            <tr>
                <td></td>
                <td><input type="submit" value="Envoyer"></td>
            </tr>
        </table>
    </form>

    <br><br>

<?php
if (
    !empty($_POST['le_nom']) &&
    !empty($_POST['le_prenom']) &&
    !empty($_POST['le_mdp']) &&
    !empty($_POST['mail'])
) {

    // Gestion date
    $dt = new DateTime($_POST['naissance']);
    $jour = $dt->format('j');
    $mois = $dt->format('F');
    $annee = $dt->format('Y');

    // Niveau d'études
    $etudes = $_POST['etudes'];
    switch ($etudes) {
        case 'pri': $etudes = "primaire"; break;
        case 'sec': $etudes = "secondaire"; break;
        case 'uni': $etudes = "universitaire"; break;
    }

    // Sexe
    $titre = "";
    if (isset($_POST['sexe'])) {
        $titre = ($_POST['sexe'] == "m") ? "Monsieur" : "Madame";
    }

    echo "<div id='reponse'>
        Bonjour $titre {$_POST['le_prenom']} {$_POST['le_nom']} <br>
        Votre mot de passe est : {$_POST['le_mdp']} <br>
        Né(e) le : $jour / $mois / $annee <br>
        Adresse mail : {$_POST['mail']} <br>
        Niveau d'études : $etudes <br>
        Votre texte :$msg <br><br>";

    if (isset($_POST['hobby'])) {
        print("Vos activités favorites : <br>");
        foreach ($_POST['hobby'] as $value) {
            print("$value <br>");
        }
    }
    
    if(!empty($POST['msg'])){
        print("<br/><br/>Merci pour votre message!!");
    }
    echo "</div>";
}
?>

</body>
</html>
