<?php
session_start();

if(empty($_SESSION['jeton']))
$_SESSION['jeton'] = bin2hex(random_bytes(32));

    // Connexion à la BDD
    $serveur = '192.168.1.253';
    $login = '6qib';
    $mdp = 'Irc2026';
    $bdname = 'bd_labo_11';

    // créer la connexion 
    $link = mysqli_connect($serveur, $login, $mdp, $bdname);
    
    //vérifié la connexion
    if(!$link){
        die("La connexion a échoué:".mysqli_connect_error());
    }

    //traitement d'inscription

    $msg = "Connexion invalide";

    if(isset($_POST["btn_submit"])){
      

        if(!empty($_POST["mdp"]) && !empty($_POST["conf_mdp"])){

            if($_POST["mdp"] == $_POST["conf_mdp"]){
              //inscrire dans la base
              $sql = "insert into inscription (Email,Password) values (?,?)";
              $stmt = mysqli_prepare($link,$sql);
              mysqli_stmt_bind_param($stmt,"ss",$_POST['e_mail'],$_POST['mdp']);
              mysqli_stmt_execute($stmt);
              //redirection
               header("Location:inscription.php");
              

            }
            else{
              $msg = "<span classe='message'> Les mdp conrrespondent pas.</span>";}
        }
        else{
          $msg = "<span classe='message'>ous devez rempir tous les champs !!!</span>";
        }
    }
    
    ?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap Registration Form</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
      body {
        background-color: #454545; /* Fond bleu très clair */
        height: 100vh; /* Utilise toute la hauteur de la fenêtre */
        display: flex;
        justify-content: center;
        align-items: center;
      }

      .container {
        background-color: #000000; /* Fond vert */
        border-radius: 10px;
        padding: 30px;
        width: 100%;
        max-width: 400px; /* Largeur maximale */
      }

      .form-control {
        margin-bottom: 15px;
      }

      h2 {
        color: white;
        text-align: center;
      }

      .message{
        color:red;
      }
      .btn-primary {
        width: 100%; /* Bouton prend toute la largeur */
      }
    </style>
  </head>
  <body>
    <div class="container">
      <h2>Inscription</h2>
      <form action="" method="post">
        <input type="hidden" name="mon_jeton" value="<?= htmlspecialchars($_SESSION['jeton']) ?> </input>
        <div class="mb-3">
          <label for="email" class="form-label text-white">Email</label>
          <input name="e_mail" type="email" class="form-control" id="email" placeholder="Entrez votre email" required>
        </div>
        <div class="mb-3">
          <label for="password" class="form-label text-white">Mot de passe</label>
          <input name="mdp" type="password" class="form-control" id="password" placeholder="Entrez votre mot de passe" required>
        </div>
        <div class="mb-3">
          <label for="confirmPassword" class="form-label text-white">Confirmer le mot de passe</label>
          <input name="conf_mdp" type="password" class="form-control" id="confirmPassword" placeholder="Confirmez votre mot de passe" required>
        </div>
        
        <button type="submit" class="btn btn-primary" name="btn_submit" >S'inscrire</button>
      </form>
    </div>

    
    

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>
