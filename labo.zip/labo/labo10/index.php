<?php
session_start();
 
$serveur ="192.168.1.253";
$login ="6qib";
$mdp="Irc2026";
$dbname ="irigaray";


$link = mysqli_connect($serveur, $login, $mdp, $dbname);

if(!$link){
    die("la connexion a echouer". mysqli_connect_error());
}


$les_films = "INSERT INTO films (titre, origine, genre, duree, version, code, vision, acteurs , realisateur, synopsis, statut, trailer, affiche) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)";
$stmt = mysqli_prepare($link, $les_films);
mysqli_stmt_bind_param($stmt,"sssisssssssss",$titre,$origine,$genre,$duree,$version,$code,$vision,$acteurs,$realisateur,$synopsis,$statut,$trailer,$affiche);














?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Labo 10 (BD + bootstrap)</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
    <style>
        .table{
            width:1100px;
            margin:auto auto;
        }
        td{
            /*border:1px solid black;*/
        }
        #form_filtre{
            margin:25px;
        }
    </style>
</head>
<body>
    <h3>Y</h3>

    <form action="" method="post" id="form_filtre">
        <input type="text" name="titre">
        <input type="submit" value="Rechercher un film" name="filtre_film">
    </form>

    <form action="" method="post">
        <select name="statut">
            <option value="AFFICHE">Films à l'affiche</option>
            <option value="ARCHIVE">Films archivés</option>
        </select>
        <input type="submit" value="Filtrer les films" name='statut_film'>
    </form>



    <table>
    




    </table>
</body>
</html>
