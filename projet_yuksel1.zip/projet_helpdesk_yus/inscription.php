<?php
require_once('require.php');

$error = "";

if (isset($_POST['btn_register'])) {
    $nom = $_POST['username'];
    $email= $_POST['email'];
    $mdp_ddd = $_POST['mdp'];
    $mdp_hasher = password_hash($_POST['mdp'], PASSWORD_DEFAULT);

    $query = "INSERT INTO users (nom, email, mot_de_passe, role, cree_le) VALUES (?, ?, ?, 'user', NOW())";
    $stmt  = mysqli_prepare($db, $query);
    mysqli_stmt_bind_param($stmt, "sss", $nom, $email, $mdp_hasher);

    if (mysqli_stmt_execute($stmt)) {
        header('Location: connexion.php');
        exit;
    } else {
        $error = "Erreur dans le systeme.";
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Inscription</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1 >Inscription</h1>

    <?php if ($error){ ?>
        <p class="msg-error"><?= $error ?></p>
    <?php } ?>

    <form action="" method="POST">
        <label>Nom</label>
        <input type="text" name="username" placeholder="Votre Nom" required>

        <label>Email</label>
        <input type="email" name="email" placeholder="Votre Mail" required>

        <label>Mot de passe</label>
        <input type="password" name="mdp" placeholder="Votre Mot de passe" required>

        <button type="submit" name="btn_register">S'inscrire</button>
    </form>
    <a href="index.php"><button type="button" style="margin-top: 20px;">Vous avez déjà un compte ?</button></a>
</body>
</html>