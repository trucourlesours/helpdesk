<?php
session_start();
 
$serveur    = 'localhost';
$dbname  = 'projet_helpdesk';
$login  = 'root';
$mdp  = '';
 
$db = mysqli_connect($serveur, $login, $mdp, $dbname);
 
if (!$dbname) {
    die("Erreur de connexion : " . mysqli_connect_error());
}
?>