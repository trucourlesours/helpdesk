<?php
session_start()
 
if(isset($_SESSION['login'])){
  print($_SESSION['login']);
}
else{
  header('Location:login.php');
}




















?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PPC Arena – Combat !</title>
  <link rel="stylesheet" href="css/styles.css">
</head>
<body>

  <div class="page-game">

    <!-- ── BARRE DU HAUT ── -->
    <div class="topbar">
      <div class="player-info">
        <div class="avatar">🧑</div>
        <div>
          <div class="player-name">Joueur</div>
          <div class="player-sub">En jeu</div>
        </div>
      </div>
      <a href="logout.php" class="btn btn-small btn-danger">🚪 Quitter</a>
    </div>

    <!-- ── TITRE ── -->
    <div style="text-align:center; margin-bottom:24px;">
      <h1 class="titre-principal">⚔️ PPC Arena</h1>
      <p class="sous-titre">Meilleur des 3 manches · 3 essais par manche</p>
    </div>

    <!-- ── SUIVI DES MANCHES ── -->
    <div class="manches">
      <div class="manche active">
        <div class="manche-label">Manche 1</div>
        <div class="manche-score">–</div>
      </div>
      <div class="manche">
        <div class="manche-label">Manche 2</div>
        <div class="manche-score">–</div>
      </div>
      <div class="manche">
        <div class="manche-label">Manche 3</div>
        <div class="manche-score">–</div>
      </div>
    </div>

    <!-- ── SCORE GLOBAL (manches gagnées) ── -->
    <div class="score-global">
      <div>
        <div class="score-label">Toi</div>
        <div class="score-chiffre joueur">0</div>
      </div>
      <div class="score-vs">VS</div>
      <div>
        <div class="score-label">Ordi</div>
        <div class="score-chiffre ordi">0</div>
      </div>
    </div>

    <!-- ── ESSAIS DE LA MANCHE EN COURS ── -->
    <div class="essais-label">Essais de la manche</div>
    <div class="essais-dots">
      <div class="dot"></div>
      <div class="dot"></div>
      <div class="dot"></div>
    </div>

    <!-- ── RÉSULTAT DU DERNIER ESSAI ── -->
    <div class="resultat-box">
      <p class="resultat-vide">Fais ton choix ci-dessous !</p>
    </div>

    <!-- ── BOUTONS DE CHOIX ── -->
    <div class="choix-titre">Ton choix</div>
    <form action="jeu.php" method="POST" class="choix-form">
      <button type="submit" name="choix" value="pierre" class="btn-choix btn-pierre">
        <span class="choix-emoji">🪨</span>
        <span class="choix-nom">Pierre</span>
        <span class="choix-info">écrase Ciseaux</span>
      </button>
      <button type="submit" name="choix" value="papier" class="btn-choix btn-papier">
        <span class="choix-emoji">📄</span>
        <span class="choix-nom">Papier</span>
        <span class="choix-info">couvre Pierre</span>
      </button>
      <button type="submit" name="choix" value="ciseaux" class="btn-choix btn-ciseaux">
        <span class="choix-emoji">✂️</span>
        <span class="choix-nom">Ciseaux</span>
        <span class="choix-info">coupe Papier</span>
      </button>
    </form>

    <!-- ── FIN DE PARTIE (affiché par PHP quand la partie est terminée) ── -->
    <div class="fin-partie" id="finPartie" style="display:none;">
      <div class="fin-emoji">🏆</div>
      <h2 class="fin-titre victoire">Bravo, tu as gagné !</h2>
      <p class="fin-sous">Résultat enregistré dans la base de données.</p>
      <br>
      <a href="jeu.php?reset=1" class="btn btn-success">🔄 Rejouer</a>
    </div>

    <p class="footer-note">Labo Informatique · <span>6ème</span></p>

  </div>

</body>
</html>
