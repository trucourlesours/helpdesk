-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mer. 13 mai 2026 à 21:57
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `projet_helpdesk`
--

-- --------------------------------------------------------

--
-- Structure de la table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `id_ticket` int(11) NOT NULL COMMENT 'pour lier au ticket',
  `id_utilisateur` int(11) NOT NULL COMMENT 'pour savoir qui a écrit',
  `message` text NOT NULL COMMENT 'le contenu du message',
  `cree_le` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `messages`
--

INSERT INTO `messages` (`id`, `id_ticket`, `id_utilisateur`, `message`, `cree_le`) VALUES
(18, 15, 4, 'montre moi un screen', '2026-05-11 13:41:26'),
(19, 16, 4, 'ba va chez orange', '2026-05-11 13:41:29'),
(20, 15, 1, 'ok', '2026-05-10 19:55:19'),
(21, 19, 2, 'testtttt', '2026-05-11 13:40:42'),
(22, 15, 3, 'le screen??', '2026-05-10 19:56:28'),
(23, 16, 3, 'bro', '2026-05-10 19:56:44');

-- --------------------------------------------------------

--
-- Structure de la table `tickets`
--

CREATE TABLE `tickets` (
  `id` int(11) NOT NULL,
  `sujet` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `id_utilisateur` int(11) NOT NULL,
  `cree_le` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `statut` enum('ouvert','en_cours','fermer') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `tickets`
--

INSERT INTO `tickets` (`id`, `sujet`, `message`, `id_utilisateur`, `cree_le`, `statut`) VALUES
(15, 'j\'ai un probleme', 'rien ne marche dans votre site', 1, '2026-05-13 19:00:01', 'ouvert'),
(16, 'probleme de reseaux', 'Je suis chez proximus et ils me facture 10k le mois', 1, '2026-05-10 19:50:37', 'ouvert'),
(17, 'mon processeur ne marche pas', 'j\'ai pas mis de pate thermique', 1, '2026-05-10 19:54:36', 'en_cours'),
(18, 'j\'ai un probleme de fps ', 'mon jeu tourne sous 15fps', 1, '2026-05-10 19:47:51', 'ouvert'),
(19, 'test', 'test', 2, '2026-05-11 13:40:20', 'ouvert'),
(20, 'pixel mort', 'mon ecran est noir', 2, '2026-05-11 13:40:24', 'ouvert'),
(21, 'ma manette n\'est pas reconnu sur mon pc', 'ma manette est nouvelle et elle ne marche pas', 2, '2026-05-11 13:40:28', 'ouvert'),
(22, 'je suis un hacker', 'donne moi tes codes bancaires', 2, '2026-05-11 13:59:32', 'fermer'),
(25, 'je suis le boss', 'je suis le boss', 4, '2026-05-13 16:28:32', 'ouvert');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `mot_de_passe` varchar(255) NOT NULL,
  `role` enum('user','technicien','admin') NOT NULL,
  `cree_le` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `nom`, `email`, `mot_de_passe`, `role`, `cree_le`) VALUES
(1, 'test', 'test@gmail.com', '$2y$10$bd4KLKWlyBnpeCG37BEgx.uuw2EWNo89EOb.GthJJinieyh7fnpb.', 'user', '2026-05-13 19:03:15'),
(2, 'test2', 'test2@gmail.com', '$2y$10$wga8LHq1ZqbfBorvjLDqGemzi7H8kbWW2D3qUExHHQ2bD45J7m.NO', 'user', '2026-05-11 13:41:12'),
(3, 'technicien', 'technicien@gmail.com', '$2y$10$ANQ.B0vslKRP0hkr4NCEL.XvU1THT2GCxXqElq.rR30pf1/mj/5pq', 'technicien', '2026-05-11 13:38:38'),
(4, 'boss', 'boss@gmail.com', '$2y$10$5qS8GrH3G.2r5ZUPmRtN9OOm9Zhan/9iGq4gH0KkrL01KWMNN9lSK', 'admin', '2026-05-11 13:41:01');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT pour la table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
