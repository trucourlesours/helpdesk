<?php
require_once('require.php');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mes tickets</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1 style="color:black;">Mes tickets</h1>

    <a href="la_base.php"><button type="button">Retour</button></a>

    <table>
        <thead>
            <tr>
                <th>Sujet</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $query = "SELECT * FROM tickets WHERE id_utilisateur = ?";
            $stmt  = mysqli_prepare($db, $query);
            mysqli_stmt_bind_param($stmt, "i", $_SESSION['user_id']);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);

            while ($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?= $row['sujet'] ?></td>
                    <td><a href="ticket2.php?id=<?= $row['id'] ?>">Voir</a></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <form action="ticket3.php" method="get">
        <button type="submit" name="btn_submit">Créer un ticket</button>
    </form>
</body>
</html>