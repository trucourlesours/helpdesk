<?php
require_once('require.php');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Accueil</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>Bonjour, <?= $_SESSION['username'] ?></h1>

    <div class="dashboard">
        <a href="ticket.php" class="box box--large">
            <h2>Mes tickets</h2>
        </a>

        <?php if ($_SESSION['role'] === 'technicien' || $_SESSION['role'] === 'admin'){ ?>
            <a href="lesboss.php" class="box box--large">
                <h2>Admin</h2>
                <p>Gérer les tickets</p>
            </a>
        <?php }; ?>
    </div>

    <a href="index.php" class="btn-deco" style="margin-top: 20px;">Déconnexion</a>
</body>