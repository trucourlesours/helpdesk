<!DOCTYPE html>
<html lang="en">    
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Labo 10 </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
    <style>
        .table{
            width: 700;
            margin: auto auto ;
            border:1px solid black ;

        }
        td{
            border:1px solid black ;
        }
        th{
            border:2px solid black ;
        }
        #form_filtre{
            margin:25px;
        }
        #archive_affiche{
            margin:25px;
        }
        a{
            color:red;   
            text-decoration: none;
        }
    </style>
    
</head>
<body>
    <h2>Yuksel</h2>

        <form action="" method="post" id="form_filtre">
            <input type="text" name="titre">
            <input type="submit" value="Rechercher un film" name="filtre_film " class="btn btn-success">
             
        </form>
        <form action="" method="post" id="archive_affiche">
            <select name="option">
                    <option value="ARCHIVE">Films archivés</option>
                    <option value="AFFICHE">Films en affiche</option>
                </select>
            <input type="submit" value="Filtres les films" name="archive_affiche" class="btn btn-success">
        </form>
        
        
    <?php
    $serveur = '192.168.1.253';
    $login = '6qib';
    $mdp = 'Irc2026';
    $bdname = 'irigaray';

    $link = mysqli_connect($serveur, $login, $mdp, $bdname);
    if(!$link){
        die("La connexion a échoué:".mysqli_connect_error());
    }
    
    

    if(isset($_POST['effacer'])) {

        //preparation
        $stmt= mysqli_prepare($link,"delete from films where id= ? and statut<>'AFFICHE'");

        //bind parametres
        mysqli_stmt_bind_param($stmt,"i",$id);

        foreach ($_POST['del'] as $value){
           // mysqli_query($link,"delete from films where id=".$value); 
           $id=(int)$value;
           //execution 
           mysqli_stmt_execute($stmt);
        }
    }

   $tri= "order by titre ASC";
   if(isset($_GET['tri'])){
     switch($_GET['tri']){
        case 'origine':$tri = "order by origine ASC";break;
        case 'dateSortie':$tri = "order by dateSortie ASC";break;
     }
   }



    $resultat = mysqli_query($link,"SELECT * from films ".$tri);
     
    if(isset($_POST['filtre_film']) && !empty($_POST['titre'])){
        $resultat = mysqli_query($link,"SELECT * from films where titre LIKE '%".$_POST['titre']."%' order by titre ASC");
    } 
     if(isset($_POST['archive_affiche'])){
        $resultat = mysqli_query($link,"SELECT * from films where statut ='".$_POST['option']."' order by titre ASC");
        print("il y'a ".mysqli_num_rows($resultat)." films trouvé ");
    } 

    

    
    // var_dump($resultat);
    if(mysqli_num_rows($resultat) > 0){
            print("
            <form action='' method='post'>
            <table class='table table-striped'>
                        <tr>
                        <th><a href='index.php?tri=titre' class='btn btn-danger' >Titre</a></th>
                        <th><a href='index.php?tri=origine' class='btn btn-danger' >Origine</a></th>
                        <th><a href='index.php?tri=dateSortie' class='btn btn-danger' >Date de Sortie</a></th>
                        <th>Effacer</th>
                        
        </tr>");

        while ($ligne = mysqli_fetch_assoc($resultat)) {

            print("<tr>
            
                    <td>".$ligne['titre']."</td>
                    <td>".$ligne['origine']."</td>
                    <td>".$ligne['dateSortie']."</td>
                    <td><input type='checkbox' name='del[]' value='".$ligne['id']."'</td>
                <tr>");
            
            }
            print("
            <tr>
            <td></td>
            <td></td>
            <td></td>
            <td><input type='submit' class='btn btn-primary' value='Effacer' name='effacer' onclick=\"return confirm('Vous voulez vraiment effacer ces films ?');\"</td>
            </tr></table></form>");
            
        
    }

    ?>
</body>
</html>