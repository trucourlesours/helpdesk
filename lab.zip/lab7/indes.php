<?php
//var_dump($_POST);


$login="";
$mdp="";
$msg_erreur="";
$msg_con="";

if(!empty($_POST['mdp']) && !empty($_POST['log'])){
$login = $_POST['log'];
$mdp = $_POST['mdp'];
if($login=="eleve" && $mdp=="6qib"){
    $msg_con ="vous etes connecter";

}
else{
    $msg_con="<span style='color:red'>vous n'etes pas reconnue par le systeme";
}
}
else{
    $msg_erreur="Veuillez remplir tous les champs !";
}







?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
        div{
            width:300px;
            margin:auto auto;
            border:2px solid black;
            padding:15px;
            text-align:center;
        }





    </style>
</head>
<body>
<h2>Yuksel  </h2>

<div>
    <form action="" method="post">
        <table>
            <tr>
                <td>Login:</td><td><input type="text" name="log"></td>
            </tr>
            <tr>
                <td>mot de passe:</td><td><input type="password" name="mdp"></td>
            </tr>
            <tr>
                <td></td><td><input type="submit" value="Connexion" name="bouton"></td>
            </tr>
        </table>
    </form>
    <?php
    if(isset($_POST['bouton'])){
    if($msg_erreur!=""){
        print($msg_erreur);
    }
    else{
        print($msg_con);
    }
    }





    ?>
</div>














    
</body>
</html>