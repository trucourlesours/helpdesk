<?php
           session_start();
         /*connexion à une BD MySql */
        
        $serveur = 'localhost';
        $dbname  ='irigaray';
        $login = '192.168.1.253';
        $mdp ='Irc2026';
        
        // Créer la connexion

        $link = mysqli_connect($serveur,$login,$mdp,$dbname);

        // Vérifier la connexion
    if (!$link) {
        die("La connexion a échoué: " . mysqli_connect_error());
    }

    $res = mysqli_query($link,"select * from films");
    
    if(isset($_POST['btn_filtre']) && !empty($_POST['filtre'])){
       $res = mysqli_query($link,"select * from films where titre LIKE '%".$_POST['filtre']."%'"); 
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cinéma</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
    <style>
        body{
            background-color:black;
            color:white;
        }
        .card-body{
            background-color:#faf5e6;
        }
        .card-footer{
            background-color:#505050;
            
        }
        .text-body-secondary{
            color:white !important;
        }

        .card img{
            height:380px;
        }

    </style>
</head>
<body>
<div class="container">
    <div class="d-flex justify-content-between p-3">
        <h2>Irigaray</h2>
        <form action="" method="post">
            <input type="text" name="filtre"  placeholder="🔎">
            <input type="submit" value="🔎" name="btn_filtre">
        </form>
    </div>
    <div class="row row-cols-1 row-cols-md-4 g-4">
        <?php
            while($ligne = mysqli_fetch_assoc($res)){
                print("<div class='col'>
                        <div class='card h-100'>
                        <img src='images/".$ligne['affiche']."' class='card-img-top' alt='...'>
                        <div class='card-body'>
                            <h5 class='card-title'>".$ligne['titre']."</h5>
                            <p class='card-text'>
                            ".$ligne['synopsis']."
                            </p>
                        </div>
                        <div class='card-footer d-flex justify-content-between'>
                            <div>
                                <small class='text-body-secondary'>Durée: ".$ligne['duree']."</small><br/>
                                <small class='text-body-secondary'>Version: ".$ligne['version']."</small>
                            </div>
                            <div>
                                <a href='https://www.youtube.com/watch?v=".$ligne['trailer']."' target='_blank'>
                                    <img src='images/youtube.png' style='width:50px;height:50px'>
                                </a>
                            </div>
                        </div>
                        </div>
                    </div>");
            }
        ?>
        
    </div>
</div>
</body>
</html>