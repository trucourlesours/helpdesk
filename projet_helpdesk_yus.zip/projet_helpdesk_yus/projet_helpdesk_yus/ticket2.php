<?php
require_once("require.php");

$ticket_id = $_GET['id'];

if (isset($_POST['btn_send'])) {
    $message = $_POST['msg_input'];

    $query = "INSERT INTO messages (id_ticket, id_utilisateur, message, cree_le) VALUES (?, ?, ?, NOW())";
    $stmt  = mysqli_prepare($db, $query);
    mysqli_stmt_bind_param($stmt, "iis", $ticket_id, $_SESSION['user_id'], $message);
    mysqli_stmt_execute($stmt);

    header('Location: ticket2.php?id=' . $ticket_id);
    exit;
}

$q_ticket = "SELECT * FROM tickets WHERE id = ?";
$s_ticket = mysqli_prepare($db, $q_ticket);
mysqli_stmt_bind_param($s_ticket, "i", $ticket_id);
mysqli_stmt_execute($s_ticket);
$ticket = mysqli_fetch_assoc(mysqli_stmt_get_result($s_ticket));

$q_msg = "SELECT messages.*, users.nom FROM messages 
          JOIN users ON messages.id_utilisateur = users.id
          WHERE id_ticket = ?";
$s_msg = mysqli_prepare($db, $q_msg);
mysqli_stmt_bind_param($s_msg, "i", $ticket_id);
mysqli_stmt_execute($s_msg);
$messages = mysqli_stmt_get_result($s_msg);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Ticket</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="card">
        <a href="ticket.php"><button type="button">Retour</button></a>

        <h1 >Sujet : <?= $ticket['sujet'] ?></h1>
        <p>Message : <?= $ticket['message'] ?></p>
        <p>Temps : <?= $ticket['cree_le'] ?></p>
        <p>Statut : <?= $ticket['statut'] ?></p>

        <hr>

        <?php while ($row = mysqli_fetch_assoc($messages)): ?>
            <p><strong><?= $row['nom'] ?></strong> : <?= $row['message'] ?> <small>(<?= $row['cree_le'] ?>)</small></p>
        <?php endwhile; ?>

        <hr>

        <?php if ($ticket['statut'] === 'fermer'): ?>
            <p class="msg-error">TICKET FERMÉ</p>
        <?php elseif ($ticket['statut'] === 'en_cours'): ?>
            <p>TICKET EN COURS, VEUILLEZ ATTENDRE LE STAFF</p>
        <?php else: ?>
            <form action="" method="POST">
                <label>Votre message</label>
                <textarea name="msg_input" placeholder="Écrivez votre message..." required></textarea>
                <button type="submit" name="btn_send">Envoyer</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>