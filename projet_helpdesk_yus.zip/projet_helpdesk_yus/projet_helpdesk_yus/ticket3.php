<?php
require_once('require.php');

$error = "";

if (isset($_POST['btn_submit'])) {
    $sujet   = $_POST['t_sujet'];
    $message = $_POST['t_message'];
    $user_id = $_SESSION['user_id'];

    $query = "INSERT INTO tickets (sujet, message, id_utilisateur, statut, cree_le) VALUES (?, ?, ?, 'ouvert', NOW())";
    $stmt  = mysqli_prepare($db, $query);
    mysqli_stmt_bind_param($stmt, "ssi", $sujet, $message, $user_id);

    if (mysqli_stmt_execute($stmt)) {
        header('Location: ticket.php');
        exit;
    } else {
        $error = "Erreur lors de l'envoi.";
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Créer un ticket</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1 >Créer un ticket</h1>

    <a href="ticket.php"><button type="button">Retour</button></a>

    <?php if ($error): ?>
        <p class="msg-error"><?= $error ?></p>
    <?php endif; ?>

    <form action="" method="POST">
        <label>Sujet</label>
        <input type="text" name="t_sujet" placeholder="Le sujet" required>

        <label>Message</label>
        <textarea name="t_message" placeholder="Décrivez votre problème..." required></textarea>

        <button type="submit" name="btn_submit">Envoyer</button>
    </form>
</body>
</html>