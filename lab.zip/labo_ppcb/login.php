<?php
session_start()






$mdp_user = $_POST['mdp'];

$sql = "select * from utilisateur where ogin = ? and mot_de_passe = ?"
$stmt = mysqli_prepare($link,$sql);
mysqli_stmt_bind_param();














?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PPC Arena – Connexion</title>
  <link rel="stylesheet" href="css/styles.css">
</head>
<body>

  <div class="page">
    <div class="card">

      <div class="emoji-row">
        <span>🪨</span>
        <span>📄</span>
        <span>✂️</span>
      </div>

      <h1 class="titre-principal">PPC Arena</h1>
      <p class="sous-titre">Pierre · Papier · Ciseaux — Qui sera le champion ?</p>

      <!-- Message d'erreur affiché par PHP si le login échoue -->
      <div class="msg-erreur" id="erreur" style="display:none;">
        ❌ Identifiant ou mot de passe incorrect !
      </div>

      <form action="jeu.php" method="POST">
        <div class="field">
          <label>👤 Identifiant</label>
          <input type="text" name="login" placeholder="Ton pseudo..." autocomplete="off" required>
        </div>
        <div class="field">
          <label>🔒 Mot de passe</label>
          <input type="password" name="mdp" placeholder="••••••••" required>
        </div>
        <button type="submit" class="btn btn-primary">
          🎮 Entrer dans l'arène !
        </button>
      </form>

      <p class="footer-note" style="margin-top:20px;">Labo Informatique · <span>6ème</span></p>
    </div>
  </div>

</body>
</html>
